from flask import Flask, redirect, url_for, request, render_template, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin
from flask_login import login_required, login_user, logout_user, current_user


app = Flask(__name__)
db = SQLAlchemy(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.secret_key = 'secret'


class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10000))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))



class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), nullable=False)
    password = db.Column(db.String(40), nullable=False)
    notes = db.relationship('Note')

    def __str__(self):
        return f'id-{self.id} username-{self.username} password-{self.password}'


login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)


@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))


@app.route('/', methods=['POST', 'GET'])
@login_required
def home():
    if request.method == 'POST':
        note = request.form.get('note')

        if len(note) < 1:
            flash('Note is too short', category='error')
        else:
            new_note = Note(data=note, user_id=current_user.id)
            db.session.add(new_note)
            db.session.commit()
            flash('Note added!')

    # data = User.query.all()
    return render_template('home.html', user=current_user)


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']


        checking_users_existing = User.query.filter_by(username=username).first()
        print(checking_users_existing)

        if checking_users_existing:
            if check_password_hash(checking_users_existing.password, password):
                flash('You have logged in successfully')
                session['username'] = username
                login_user(checking_users_existing, remember=True)
                return redirect(url_for('home'))
            else:
                flash('Incorrect password, try again.', category='error')
        else:
            flash('Username does not exist', category='error')

        if checking_users_existing is None:
            flash('Check if username or password is correct!', category='error')



    return render_template('login.html')


@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        def add_user_db(username, password):
            checking_users_existing = User.query.filter_by(username=username).first()
            print(checking_users_existing)

            if checking_users_existing:
                flash('this username already exists try another', category='error')

            else:
                user = User(username=username, password=generate_password_hash(password))
                db.session.add(user)
                db.session.commit()
                # login_user(checking_users_existing, remember=True)
                flash('Account Created!')




        # def read_users_from_db():

        username = request.form['username']
        password1 = request.form['password1']
        password2 = request.form['password2']

        if password2 == password1:
            if password2 != '' and password1 != '':
                add_user_db(username, password1)
            else:
                flash('enter password ;)', category='info')

        else:
            flash('password don\'t match!', category='error')

    return render_template('register.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.pop('username', None)
    return redirect(url_for('login'))


@app.route('/dashboard')
@login_required
def dashboard():
    users = User.query.all()

    return render_template('dashboard.html', users=users)



@app.route('/CATAPI')
@login_required
def CATAPI():
    return render_template('CATAPI.html')


if __name__ == '__main__':
    db.create_all(app=app)
    app.run(debug=True)
